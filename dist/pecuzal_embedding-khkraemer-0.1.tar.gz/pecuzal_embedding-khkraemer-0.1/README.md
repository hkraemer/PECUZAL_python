PECUZAL Python
==============

Find the necessary functions in the `src`-folder and the corresponding tests in the `test`-folder.
